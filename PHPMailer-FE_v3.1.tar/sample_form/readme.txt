To be fully functional, include:

phpmailer-fe.php
class.phpmailer.php

in the _lib/ directory and set the basic settings.

Strategies employed in this sample form:

* phpmailer-fe.php is in the _lib/ directory
* class.phpmailer.php is in the _lib/ directory 
  - means phpmailer-fe.php will use class.phpmailer.php to handle the sending of data
* the reply email templates are in the _lib/ directory
  - means that class.phpmailer.php will use the images from its local _lib/_src/ directory
  note: if you put the reply email templates in any other directory, change
        the <img tag to an explicit URL for source
* the landing pages templates are in the _lib/ directory
  - phpmailer-fe.php will not substitute the image tags ...
  note: if you put the landing pages templates in any other directory, change
        the <img tag to an explicit URL for source

Enjoy!